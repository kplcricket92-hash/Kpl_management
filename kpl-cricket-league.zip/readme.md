cricket-league/
│
├── index.html
├── admin-login.html
├── admin-dashboard.html
├── team-profile.html
├── style.css
├── script.js
├── admin.js
├── profile.js
├── firebase.js
├── pdf.js